import pandas as pd
import matplotlib.pyplot as plt

hypothroid_data = pd.read_excel("hypothyroid.xlsx", na_values='?')

# Calculating measures

print("mean(age):", hypothroid_data['age'].mean())	#Output: 51.628
print("std(age):", hypothroid_data['age'].std())	#Output: 18.98


# Visualizing 
x = hypothroid_data['age']
y = hypothroid_data['Class']

plt.xlabel('age', fontsize=20)
plt.ylabel('Class', fontsize=20)
plt.title("Scatter plot between age and Class label")
plt.scatter(x,y, s= 20);

# Output: scatterplot (Image included in the Task2 folder)