#!/usr/bin/env python
# coding: utf-8

# In[148]:


import pandas as pd
import numpy as np
from sklearn import preprocessing
import matplotlib.pyplot as plt


# In[25]:


hypothroid_data = pd.read_excel("hypothyroid.xlsx", na_values='?')


# In[ ]:


# Issue with the hypothroid_data set: Most of the data values are missing and there are many outliers for some of the attributes
# Now, let's check the missing cells of each attributes and replace it with appropiate strategies.


# In[174]:


# Check if there is any missing values in attribue 'age'
hypothroid_data['age'].isnull().values.any()


# In[60]:


hypothroid_data['sex'].isnull().values.any()


# In[81]:


# since it is binary attribute we can use mode to replace the missing values
hypothroid_data['sex'] = hypothroid_data['sex'].fillna(hypothroid_data['sex'].mode()[0])
hypothroid_data['sex'].isnull().values.any()


# In[83]:


hypothroid_data['on thyroxine'].isnull().values.any()


# In[85]:


hypothroid_data['on thyroxine'].isnull().values.any()


# In[84]:


hypothroid_data['query on thyroxine'].isnull().values.any()


# In[86]:


hypothroid_data['query on thyroxine'].isnull().values.any()


# In[87]:


hypothroid_data['on antithyroid medication'].isnull().values.any()


# In[88]:


hypothroid_data['sick'].isnull().values.any()


# In[89]:


hypothroid_data['pregnant'].isnull().values.any()


# In[90]:


hypothroid_data['thyroid surgery'].isnull().values.any()


# In[91]:


hypothroid_data['I131 treatment'].isnull().values.any()


# In[92]:


hypothroid_data['I131 treatment'].isnull().values.any()


# In[93]:


hypothroid_data['query hypothyroid'].isnull().values.any()


# In[94]:


hypothroid_data['query hyperthyroid'].isnull().values.any()


# In[95]:


hypothroid_data['lithium'].isnull().values.any()


# In[96]:


hypothroid_data['goitre'].isnull().values.any()


# In[97]:


hypothroid_data['tumor'].isnull().values.any()


# In[98]:


hypothroid_data['hypopituitary'].isnull().values.any()


# In[99]:


hypothroid_data['psych'].isnull().values.any()


# In[100]:


hypothroid_data['TSH'].isnull().values.any()


# In[118]:


hypothroid_data.boxplot(column=['TSH'])


# In[101]:


# Since there are many outliers we can use modian
hypothroid_data['TSH'] = hypothroid_data['TSH'].fillna(hypothroid_data['TSH'].median())
hypothroid_data['TSH'].isnull().values.any()


# In[120]:


hypothroid_data['T3'].isnull().values.any()


# In[119]:


hypothroid_data.boxplot(column=['T3'])


# In[121]:


# Since there are many outliers we can use modian
hypothroid_data['T3'] = hypothroid_data['T3'].fillna(hypothroid_data['T3'].median())
hypothroid_data['T3'].isnull().values.any()


# In[123]:


hypothroid_data['TT4'].isnull().values.any()


# In[124]:


hypothroid_data.boxplot(column=['TT4'])


# In[125]:


# Since there are many outliers we can use modian
hypothroid_data['TT4'] = hypothroid_data['TT4'].fillna(hypothroid_data['TT4'].median())
hypothroid_data['TT4'].isnull().values.any()


# In[126]:


hypothroid_data['T4U'].isnull().values.any()


# In[127]:


hypothroid_data.boxplot(column=['T4U'])


# In[128]:


# Since there are many outliers we can use modian
hypothroid_data['T4U'] = hypothroid_data['T4U'].fillna(hypothroid_data['T4U'].median())
hypothroid_data['T4U'].isnull().values.any()


# In[129]:


hypothroid_data['FTI'].isnull().values.any()


# In[130]:


hypothroid_data.boxplot(column=['FTI'])


# In[139]:


# Since there are many outliers we can use modian
hypothroid_data['FTI'] = hypothroid_data['FTI'].fillna(hypothroid_data['FTI'].median())
hypothroid_data['FTI'].isnull().values.any()


# In[144]:


sum(hypothroid_data['TBG'].isnull().values)


# In[ ]:


# We can see that all the cells of 'TBG' attributes are missing
# It is best to remove this attribute, which also "reduces" the dimension of dataset


# In[145]:


# drop the 'TBG' attribute
hypothroid_data = hypothroid_data.drop(hypothroid_data.columns[[22]], axis=1) 


# In[147]:


hypothroid_data['referral source'].isnull().values.any()


# In[151]:


# Normalizing attribuite: 'age'
hypothroid_data.boxplot(column=['age'])


# In[168]:


# From the box plot of 'age', we can see that there is no outliers hence, me can make use of Min Max Scaling

normalized_age=(hypothroid_data['age']-hypothroid_data['age'].min())/(hypothroid_data['age'].max()-hypothroid_data['age'].min())


# In[170]:


hypothroid_data['age'] = normalized_age


# In[173]:


# Now everything is done, we can get save our preprocessed thyroid data
hypothroid_data.to_excel('hypothroid_preprocessed.xlsx')


# In[ ]:




