#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Importing the relevant libraries and modules
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense
from keras.utils import np_utils
import matplotlib.pyplot as plt
import numpy as np

# load mnist data set
(X_train, y_train), (X_test, y_test) = mnist.load_data()

# X_train and X_test are three dimensional matrices
# X_train --> (60000, 28, 28)
# y_train --> (10000, 28, 28)

# y_train and y_test are vectors 
# y_train --> (60000,)
# y_test  --> (10000,)

# Visualizing the some of the images
plt.subplot(221)
plt.imshow(X_train[0], cmap=plt.get_cmap('gray'))

plt.subplot(222)
plt.imshow(X_train[1], cmap=plt.get_cmap('gray'))

plt.subplot(223)
plt.imshow(X_train[2], cmap=plt.get_cmap('gray'))

plt.subplot(224)
plt.imshow(X_train[3], cmap=plt.get_cmap('gray'))

#plt.savefig("First four images")


# In[4]:


# PREPROCESSING

# save original test data and labels
actual_test_labels = y_test
actual_test_data = X_test

#flatten 28*28 images to a 784 vector for each image
num_pixels = X_train.shape[1] * X_train.shape[2]
X_train = X_train.reshape((X_train.shape[0], num_pixels)).astype('float32')
X_test = X_test.reshape((X_test.shape[0], num_pixels)).astype('float32')

# normalize inputs from 0-255 to 0-1
X_train = X_train / 255
X_test = X_test / 255

# one hot encode outputs
y_train = np_utils.to_categorical(y_train)
y_test = np_utils.to_categorical(y_test)


# In[5]:


y_train[0]
actual_test_labels


# In[6]:


num_classes = y_test.shape[1]


# create model
model = Sequential()
model.add(Dense(num_pixels, input_dim=num_pixels, activation='sigmoid'))
model.add(Dense(num_classes, activation='sigmoid'))

model.summary()


# In[7]:


# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])


# Fit the model
model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=60000, verbose=2)


# Final evaluation of the model
scores = model.evaluate(X_test, y_test, verbose=0)
print("Error is: %.2f%%" % (100-scores[1]*100))


# In[8]:


# Predicting the output of first four X_test images
pred = model.predict(X_test[0:4], batch_size=10, verbose=0)


# In[9]:


# Visualizing the some of the X_test images
plt.subplot(221)
plt.imshow(actual_test_data[0], cmap=plt.get_cmap('gray'))

plt.subplot(222)
plt.imshow(actual_test_data[1], cmap=plt.get_cmap('gray'))

plt.subplot(223)
plt.imshow(actual_test_data[2], cmap=plt.get_cmap('gray'))

plt.subplot(224)
plt.imshow(actual_test_data[3], cmap=plt.get_cmap('gray'))


# In[10]:


for i in pred:
    max_prob = max(i)
    predicted_out = np.where(i == max_prob)
    print("\nPredicted output:", predicted_out[0], end = '')


# In[11]:


# Creating confusion matrix
predicted_class = model.predict_classes(X_test, batch_size = 10)

from sklearn import metrics
classes = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print("Confusion matrix for MLP:\n", metrics.confusion_matrix(actual_test_labels, predicted_class, labels=classes))
# y axis --> true label
# x axis --> predicted label

print("\nClassification report:\n", metrics.classification_report(actual_test_labels, predicted_class))


# In[4]:


# Simple CNN for the MNIST Dataset
from keras.datasets import mnist
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from keras.utils import np_utils
# load data
(X_train, y_train), (X_test, y_test) = mnist.load_data()

# save original test data and labels
actual_test_labels = y_test
actual_test_data = X_test


# reshape to be [samples][width][height][channels]
X_train = X_train.reshape((X_train.shape[0], 28, 28, 1)).astype('float32')
X_test = X_test.reshape((X_test.shape[0], 28, 28, 1)).astype('float32')
# normalize inputs from 0-255 to 0-1
X_train = X_train / 255
X_test = X_test / 255
# one hot encode outputs
y_train = np_utils.to_categorical(y_train)
y_test = np_utils.to_categorical(y_test)
num_classes = y_test.shape[1]


# create model
model = Sequential()
model.add(Conv2D(32, (5, 5), input_shape=(28, 28, 1), activation='relu'))
model.add(MaxPooling2D(pool_size=(3, 3)))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dense(num_classes, activation='softmax'))

model.summary()


# In[5]:


# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])


# Fit the model
model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=200)
# Final evaluation of the model
scores = model.evaluate(X_test, y_test, verbose=0)
print("CNN Error: %.2f%%" % (100-scores[1]*100))


# In[14]:


# Predicting the output of first four X_test images
pred = model.predict(X_test[0:4], batch_size=10, verbose=0)


# In[16]:


# Visualizing the some of the X_test images
plt.subplot(221)
plt.imshow(actual_test_data[0], cmap=plt.get_cmap('gray'))

plt.subplot(222)
plt.imshow(actual_test_data[1], cmap=plt.get_cmap('gray'))

plt.subplot(223)
plt.imshow(actual_test_data[2], cmap=plt.get_cmap('gray'))

plt.subplot(224)
plt.imshow(actual_test_data[3], cmap=plt.get_cmap('gray'))


# In[17]:


for i in pred:
    max_prob = max(i)
    predicted_out = np.where(i == max_prob)
    print("\nPredicted output:", predicted_out[0], end = '')


# In[18]:


# Creating confusion matrix
predicted_class = model.predict_classes(X_test, batch_size = 10)

from sklearn import metrics
classes = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print("Confusion matrix for CNN:\n", metrics.confusion_matrix(actual_test_labels, predicted_class, labels=classes))
# y axis --> true label
# x axis --> predicted label

print("\nClassification report:\n", metrics.classification_report(actual_test_labels, predicted_class))


# In[19]:


np.sum(metrics.confusion_matrix(actual_test_labels, predicted_class, labels=classes))


# In[ ]:




